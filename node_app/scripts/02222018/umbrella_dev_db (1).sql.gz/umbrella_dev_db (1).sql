-- Adminer 4.3.1 MySQL dump

SET NAMES utf8;
SET time_zone = '+00:00';
SET foreign_key_checks = 0;
SET sql_mode = 'NO_AUTO_VALUE_ON_ZERO';

DROP DATABASE IF EXISTS `umbrella_dev_db`;
CREATE DATABASE `umbrella_dev_db` /*!40100 DEFAULT CHARACTER SET latin1 */;
USE `umbrella_dev_db`;

DROP TABLE IF EXISTS `AdminCollectDistributes`;
CREATE TABLE `AdminCollectDistributes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `transactionType` varchar(255) DEFAULT NULL,
  `amount` int(11) DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  `loan_id` int(11) DEFAULT NULL,
  `admin_user_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `loan_id` (`loan_id`),
  KEY `admin_user_id` (`admin_user_id`),
  CONSTRAINT `AdminCollectDistributes_ibfk_1` FOREIGN KEY (`loan_id`) REFERENCES `Loans` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `AdminCollectDistributes_ibfk_2` FOREIGN KEY (`admin_user_id`) REFERENCES `AdminUsers` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


DROP TABLE IF EXISTS `AdminUserAccesses`;
CREATE TABLE `AdminUserAccesses` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `otp` varchar(255) DEFAULT NULL,
  `date` datetime DEFAULT NULL,
  `using_period` int(11) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  `admin_user_id` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `admin_user_id` (`admin_user_id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `AdminUserAccesses_ibfk_1` FOREIGN KEY (`admin_user_id`) REFERENCES `AdminUsers` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `AdminUserAccesses_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `Users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


DROP TABLE IF EXISTS `AdminuserCountries`;
CREATE TABLE `AdminuserCountries` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `admin_user_id` int(11) DEFAULT NULL,
  `country_id` int(11) DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `admin_user_id` (`admin_user_id`),
  KEY `country_id` (`country_id`),
  CONSTRAINT `AdminuserCountries_ibfk_1` FOREIGN KEY (`admin_user_id`) REFERENCES `AdminUsers` (`id`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `AdminuserCountries_ibfk_2` FOREIGN KEY (`country_id`) REFERENCES `Countries` (`id`) ON DELETE NO ACTION ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


DROP TABLE IF EXISTS `AdminUsers`;
CREATE TABLE `AdminUsers` (
  `FAfield` varchar(255) DEFAULT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `company_id` int(11) DEFAULT NULL,
  `role_id` int(11) DEFAULT NULL,
  `phone_number` varchar(255) DEFAULT NULL,
  `number_password_attempt` int(1) DEFAULT '0',
  `max_session_time` varchar(255) DEFAULT NULL,
  `two_factor_temp_secret` varchar(255) DEFAULT NULL,
  `otpauth_url` varchar(255) DEFAULT NULL,
  `last_login` datetime DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  `is2FAVerified` tinyint(1) DEFAULT '0',
  `photo` varchar(255) NOT NULL,
  `status` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `company_id` (`company_id`),
  KEY `role_id` (`role_id`),
  CONSTRAINT `AdminUsers_ibfk_1` FOREIGN KEY (`company_id`) REFERENCES `Companies` (`id`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `AdminUsers_ibfk_2` FOREIGN KEY (`role_id`) REFERENCES `Roles` (`id`) ON DELETE NO ACTION ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


DROP TABLE IF EXISTS `CollectionHistories`;
CREATE TABLE `CollectionHistories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `amount` double DEFAULT NULL,
  `date` datetime DEFAULT NULL,
  `currency` varchar(255) DEFAULT NULL,
  `retry_date` datetime DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `date_of_entry` datetime DEFAULT NULL,
  `bank_response` varchar(255) DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  `loan_id` int(11) DEFAULT NULL,
  `collection_id` int(11) DEFAULT NULL,
  `admin_user_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `loan_id` (`loan_id`),
  KEY `collection_id` (`collection_id`),
  KEY `admin_user_id` (`admin_user_id`),
  CONSTRAINT `CollectionHistories_ibfk_1` FOREIGN KEY (`loan_id`) REFERENCES `Loans` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `CollectionHistories_ibfk_2` FOREIGN KEY (`collection_id`) REFERENCES `Collections` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `CollectionHistories_ibfk_4` FOREIGN KEY (`admin_user_id`) REFERENCES `AdminUsers` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


DROP TABLE IF EXISTS `Collections`;
CREATE TABLE `Collections` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `amount` double DEFAULT NULL,
  `date` datetime DEFAULT NULL,
  `currency` varchar(255) DEFAULT NULL,
  `retry_date` datetime DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  `loan_id` int(11) DEFAULT NULL,
  `admin_user_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `loan_id` (`loan_id`),
  KEY `admin_user_id` (`admin_user_id`),
  CONSTRAINT `Collections_ibfk_1` FOREIGN KEY (`loan_id`) REFERENCES `Loans` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `Collections_ibfk_2` FOREIGN KEY (`admin_user_id`) REFERENCES `AdminUsers` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


DROP TABLE IF EXISTS `Companies`;
CREATE TABLE `Companies` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `company_name` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `company_address` varchar(255) DEFAULT NULL,
  `contact_number` varchar(255) DEFAULT NULL,
  `country_id` int(11) DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `country_id` (`country_id`),
  CONSTRAINT `Companies_ibfk_1` FOREIGN KEY (`country_id`) REFERENCES `Countries` (`id`) ON DELETE NO ACTION ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


DROP TABLE IF EXISTS `Countries`;
CREATE TABLE `Countries` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `country_code` varchar(255) DEFAULT NULL,
  `status` tinyint(1) DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


DROP TABLE IF EXISTS `CountryInvestments`;
CREATE TABLE `CountryInvestments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `amount_available` int(11) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  `country_id` int(11) DEFAULT NULL,
  `loan_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `country_id` (`country_id`),
  KEY `loan_id` (`loan_id`),
  CONSTRAINT `CountryInvestments_ibfk_1` FOREIGN KEY (`country_id`) REFERENCES `Countries` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `CountryInvestments_ibfk_2` FOREIGN KEY (`loan_id`) REFERENCES `Loans` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


DROP TABLE IF EXISTS `CountrySettings`;
CREATE TABLE `CountrySettings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `value` text,
  `country_id` int(11) DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `country_id` (`country_id`),
  CONSTRAINT `CountrySettings_ibfk_1` FOREIGN KEY (`country_id`) REFERENCES `Countries` (`id`) ON DELETE NO ACTION ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


DROP TABLE IF EXISTS `CreditScoreHistories`;
CREATE TABLE `CreditScoreHistories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `credit_score` double DEFAULT NULL,
  `date_processed` datetime DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `CreditScoreHistories_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `Users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


DROP TABLE IF EXISTS `DistributionCenters`;
CREATE TABLE `DistributionCenters` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `country_id` int(11) DEFAULT NULL,
  `company_id` int(11) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `lat` varchar(255) DEFAULT NULL,
  `long` varchar(255) DEFAULT NULL,
  `contact_number` varchar(255) DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `country_id` (`country_id`),
  KEY `company_id` (`company_id`),
  CONSTRAINT `DistributionCenters_ibfk_1` FOREIGN KEY (`country_id`) REFERENCES `Countries` (`id`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `DistributionCenters_ibfk_2` FOREIGN KEY (`company_id`) REFERENCES `Companies` (`id`) ON DELETE NO ACTION ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


DROP TABLE IF EXISTS `FeatureACLs`;
CREATE TABLE `FeatureACLs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `role_id` int(11) DEFAULT NULL,
  `module` varchar(255) DEFAULT NULL,
  `feature_api_url` varchar(255) DEFAULT NULL,
  `actions` text,
  `fields` text,
  `other` text,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `role_id` (`role_id`),
  CONSTRAINT `FeatureACLs_ibfk_1` FOREIGN KEY (`role_id`) REFERENCES `Roles` (`id`) ON DELETE NO ACTION ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

TRUNCATE `FeatureACLs`;
INSERT INTO `FeatureACLs` (`id`, `role_id`, `module`, `feature_api_url`, `actions`, `fields`, `other`, `created_at`, `updated_at`) VALUES
(665,	1,	'users',	'/api/admin/user',	'{\"GET\": true, \"PUT\": true }',	'{\"ALL\": true, \"status\": true, \"fname\": true, \"mname\": true, \"lname\": true, \"email\": true, \"dob\": true, \"user_location\": true, \"access_token\": true, \"phone_number\": true, \"verified\": true, \"accept\": true, \"no_of_active_loans\": true, \"sex\": true, \"profilepic\": true, \"relationship\": true, \"available_amount\": true, \"min_availalble_amount\": true, \"number_of_attempts\": true, \"last_attempts_time\": true, \"umbrella_score\": true, \"fbId\": true, \"created_at\": true, \"smscode\": true, \"uScore_status\": true, \"id_proof_file\": true, \"selfie_proof_file\": true, \"address_proof_file\": true, \"id_verification_status\": true, \"address_verification_status\": true, \"updated_at\": true, \"country_id\": true, \"LOAN\": true }',	'{ \"viewWithoutOTP\": true, \"viewWithOTP\": false, \"triggerCreditStore\": true}',	'0000-00-00 00:00:00',	'0000-00-00 00:00:00'),
(666,	1,	'loans',	'/api/admin/loan',	'{\"GET\": true, \"PUT\": true }',	'{\"ALL\": true, \"status\": true}',	'{ \"cancelLoanBasedOnStatus\": true, \"cancelLoanBasedOnStatusNotGiven\": true, \"closeLoan\": true, \"issueMoney\": true}',	'0000-00-00 00:00:00',	'0000-00-00 00:00:00'),
(667,	1,	'collections',	'/api/admin/collection',	'{\"GET\": true, \"PUT\": true }',	'{\"ALL\":true}',	'{ \"collectMoney\": true }',	'0000-00-00 00:00:00',	'0000-00-00 00:00:00'),
(669,	1,	'countries',	'/api/admin/country',	'{ \"GET\":true, \"POST\": true, \"PUT\": true, \"DELETE\": true }',	'{}',	'{}',	'0000-00-00 00:00:00',	'0000-00-00 00:00:00'),
(670,	1,	'country-settings',	'/api/admin/country-setting',	'{ \"GET\":true, \"POST\": true, \"PUT\": true, \"DELETE\": true }',	'{}',	'{}',	'0000-00-00 00:00:00',	'0000-00-00 00:00:00'),
(671,	1,	'country-investments',	'/api/admin/country-investment',	'{ \"GET\":true, \"POST\": true, \"PUT\": true, \"DELETE\": true }',	'{}',	'{}',	'0000-00-00 00:00:00',	'0000-00-00 00:00:00'),
(672,	1,	'non-supported-country-leads',	'/api/admin/non-supported-country-lead',	'{ \"GET\":true }',	'{}',	'{}',	'0000-00-00 00:00:00',	'0000-00-00 00:00:00'),
(673,	1,	'companies',	'/api/admin/company',	'{ \"GET\":true, \"POST\": true, \"PUT\": true, \"DELETE\": true }',	'{}',	'{}',	'0000-00-00 00:00:00',	'0000-00-00 00:00:00'),
(674,	1,	'distribution-centers',	'/api/admin/distribution-center',	'{ \"GET\":true, \"POST\": true, \"PUT\": true, \"DELETE\": true }',	'{}',	'{}',	'0000-00-00 00:00:00',	'0000-00-00 00:00:00'),
(675,	1,	'admin-users',	'/api/admin/admin-user',	'{ \"GET\":true, \"POST\": true, \"PUT\": true, \"DELETE\": true }',	'{}',	'{ \"createSuperAdminUser\": true, \"2FA\": true }',	'0000-00-00 00:00:00',	'0000-00-00 00:00:00'),
(677,	1,	'user-activities',	'/api/admin/user-activity-log',	'{ \"GET\":true }',	'{}',	'{}',	'0000-00-00 00:00:00',	'0000-00-00 00:00:00'),
(678,	1,	'roles',	'/api/admin/role',	'{ \"GET\":true, \"POST\": true, \"PUT\": true, \"DELETE\": true }',	'{}',	'{}',	'0000-00-00 00:00:00',	'0000-00-00 00:00:00'),
(679,	1,	'admin-user-access',	'/api/admin/admin-user-access',	'{ \"GET\":true, \"PUT\": true, \"POST\": true }',	'{}',	'{}',	'0000-00-00 00:00:00',	'0000-00-00 00:00:00'),
(680,	1,	'admin-collect-distribute',	'/api/admin/admin-collect-distribute',	'{ \"GET\":true, \"POST\": true }',	'{}',	'{}',	'0000-00-00 00:00:00',	'0000-00-00 00:00:00'),
(681,	1,	'issue-collect-money',	NULL,	'{ \"GET\":true, \"POST\": true }',	'{}',	'{ \"viewWithoutOTP\": true, \"viewWithOTP\": false}',	'0000-00-00 00:00:00',	'0000-00-00 00:00:00'),
(682,	1,	'feature-acl',	'/api/admin/feature-acl',	'{\"GET\": true, \"PUT\": true }',	'{}',	'{}',	'0000-00-00 00:00:00',	'0000-00-00 00:00:00'),
(683,	2,	'users',	'/api/admin/user',	'{\"GET\": true, \"PUT\": true }',	'{\"ALL\": true, \"status\": true, \"fname\": true, \"mname\": true, \"lname\": true, \"email\": true, \"dob\": true, \"user_location\": true, \"access_token\": true, \"phone_number\": true, \"verified\": true, \"accept\": true, \"no_of_active_loans\": true, \"sex\": true, \"profilepic\": true, \"relationship\": true, \"available_amount\": true, \"min_availalble_amount\": true, \"number_of_attempts\": true, \"last_attempts_time\": true, \"umbrella_score\": true, \"fbId\": true, \"created_at\": true, \"smscode\": true, \"uScore_status\": true, \"id_proof_file\": true, \"selfie_proof_file\": true, \"address_proof_file\": true, \"id_verification_status\": true, \"address_verification_status\": true, \"updated_at\": true, \"country_id\": true, \"LOAN\": true }',	'{ \"viewWithoutOTP\": true, \"viewWithOTP\": false, \"triggerCreditStore\": true}',	'0000-00-00 00:00:00',	'0000-00-00 00:00:00'),
(684,	2,	'loans',	'/api/admin/loan',	'{\"GET\": true, \"PUT\": true }',	'{\"ALL\": true, \"status\": true}',	'{ \"cancelLoanBasedOnStatus\": true, \"cancelLoanBasedOnStatusNotGiven\": true, \"closeLoan\": true, \"issueMoney\": false}',	'0000-00-00 00:00:00',	'0000-00-00 00:00:00'),
(685,	2,	'collections',	'/api/admin/collection',	'{\"GET\":true,\"PUT\":true}',	'{\"ALL\":true}',	'{\"collectMoney\":false}',	'0000-00-00 00:00:00',	'2018-02-19 14:17:42'),
(687,	2,	'countries',	'/api/admin/country',	'{ \"GET\":false, \"POST\": false, \"PUT\": false, \"DELETE\": false }',	'{}',	'{}',	'0000-00-00 00:00:00',	'0000-00-00 00:00:00'),
(688,	2,	'country-settings',	'/api/admin/country-setting',	'{ \"GET\":false, \"POST\": false, \"PUT\": false, \"DELETE\": false }',	'{}',	'{}',	'0000-00-00 00:00:00',	'0000-00-00 00:00:00'),
(689,	2,	'country-investments',	'/api/admin/country-investment',	'{ \"GET\":false, \"POST\": false, \"PUT\": false, \"DELETE\": false }',	'{}',	'{}',	'0000-00-00 00:00:00',	'0000-00-00 00:00:00'),
(690,	2,	'non-supported-country-leads',	'/api/admin/non-supported-country-lead',	'{ \"GET\":false }',	'{}',	'{}',	'0000-00-00 00:00:00',	'0000-00-00 00:00:00'),
(691,	2,	'companies',	'/api/admin/company',	'{ \"GET\":true, \"POST\": true, \"PUT\": true, \"DELETE\": true }',	'{}',	'{}',	'0000-00-00 00:00:00',	'0000-00-00 00:00:00'),
(692,	2,	'distribution-centers',	'/api/admin/distribution-center',	'{ \"GET\":true, \"POST\": true, \"PUT\": true, \"DELETE\": true }',	'{}',	'{}',	'0000-00-00 00:00:00',	'0000-00-00 00:00:00'),
(693,	2,	'admin-users',	'/api/admin/admin-user',	'{ \"GET\":true, \"POST\": true, \"PUT\": true, \"DELETE\": true }',	'{}',	'{ \"createSuperAdminUser\": false, \"2FA\": true }',	'0000-00-00 00:00:00',	'0000-00-00 00:00:00'),
(695,	2,	'user-activities',	'/api/admin/user-activity-log',	'{ \"GET\":true }',	'{}',	'{}',	'0000-00-00 00:00:00',	'0000-00-00 00:00:00'),
(696,	2,	'roles',	'/api/admin/role',	'{ \"GET\":false, \"POST\": false, \"PUT\": false, \"DELETE\": false }',	'{}',	'{}',	'0000-00-00 00:00:00',	'0000-00-00 00:00:00'),
(697,	2,	'admin-user-access',	'/api/admin/admin-user-access',	'{\"GET\":true,\"PUT\":true,\"POST\":true}',	'{}',	'{\"viewWithoutOTP\":true,\"viewWithOTP\":false}',	'0000-00-00 00:00:00',	'2018-02-19 14:18:28'),
(698,	2,	'admin-collect-distribute',	'/api/admin/admin-collect-distribute',	'{ \"GET\":true, \"POST\": true }',	'{}',	'{}',	'0000-00-00 00:00:00',	'0000-00-00 00:00:00'),
(699,	2,	'issue-collect-money',	NULL,	'{ \"GET\":false, \"POST\": false }',	'{}',	'{}',	'0000-00-00 00:00:00',	'0000-00-00 00:00:00'),
(700,	2,	'feature-acl',	'/api/admin/feature-acl',	'{\"GET\": true, \"PUT\": true }',	'{}',	'{}',	'0000-00-00 00:00:00',	'0000-00-00 00:00:00'),
(701,	3,	'users',	'/api/admin/user',	'{\"GET\": true, \"PUT\": true }',	'{\"ALL\": true, \"status\": true, \"fname\": true, \"mname\": true, \"lname\": true, \"email\": true, \"dob\": true, \"user_location\": true, \"access_token\": true, \"phone_number\": true, \"verified\": true, \"accept\": true, \"no_of_active_loans\": true, \"sex\": true, \"profilepic\": true, \"relationship\": true, \"available_amount\": true, \"min_availalble_amount\": true, \"number_of_attempts\": true, \"last_attempts_time\": true, \"umbrella_score\": true, \"fbId\": true, \"created_at\": true, \"smscode\": true, \"uScore_status\": true, \"id_proof_file\": true, \"selfie_proof_file\": true, \"address_proof_file\": true, \"id_verification_status\": true, \"address_verification_status\": true, \"updated_at\": true, \"country_id\": true, \"LOAN\": true }',	'{ \"viewWithoutOTP\": false, \"viewWithOTP\": true, \"triggerCreditStore\": true}',	'0000-00-00 00:00:00',	'0000-00-00 00:00:00'),
(702,	3,	'loans',	'/api/admin/loan',	'{\"GET\":true,\"PUT\":true}',	'{\"ALL\":true,\"status\":true}',	'{\"cancelLoanBasedOnStatus\":false,\"cancelLoanBasedOnStatusNotGiven\":true,\"closeLoan\":true,\"issueMoney\":false}',	'0000-00-00 00:00:00',	'2018-02-19 14:19:49'),
(703,	3,	'collections',	'/api/admin/collection',	'{\"GET\": true, \"PUT\": false }',	'{\"ALL\":false}',	'{ \"collectMoney\": false }',	'0000-00-00 00:00:00',	'0000-00-00 00:00:00'),
(705,	3,	'countries',	'/api/admin/country',	'{ \"GET\":false, \"POST\": false, \"PUT\": false, \"DELETE\": false }',	'{}',	'{}',	'0000-00-00 00:00:00',	'0000-00-00 00:00:00'),
(706,	3,	'country-settings',	'/api/admin/country-setting',	'{ \"GET\":false, \"POST\": false, \"PUT\": false, \"DELETE\": false }',	'{}',	'{}',	'0000-00-00 00:00:00',	'0000-00-00 00:00:00'),
(707,	3,	'country-investments',	'/api/admin/country-investment',	'{ \"GET\":false, \"POST\": false, \"PUT\": false, \"DELETE\": false }',	'{}',	'{}',	'0000-00-00 00:00:00',	'0000-00-00 00:00:00'),
(708,	3,	'non-supported-country-leads',	'/api/admin/non-supported-country-lead',	'{ \"GET\":false }',	'{}',	'{}',	'0000-00-00 00:00:00',	'0000-00-00 00:00:00'),
(709,	3,	'companies',	'/api/admin/company',	'{ \"GET\":false, \"POST\": false, \"PUT\": false, \"DELETE\": false }',	'{}',	'{}',	'0000-00-00 00:00:00',	'0000-00-00 00:00:00'),
(710,	3,	'distribution-centers',	'/api/admin/distribution-center',	'{ \"GET\":false, \"POST\": false, \"PUT\": false, \"DELETE\": false }',	'{}',	'{}',	'0000-00-00 00:00:00',	'0000-00-00 00:00:00'),
(711,	3,	'admin-users',	'/api/admin/admin-user',	'{ \"GET\":false, \"POST\": false, \"PUT\": false, \"DELETE\": false }',	'{}',	'{ \"createSuperAdminUser\": false, \"2FA\": true }',	'0000-00-00 00:00:00',	'0000-00-00 00:00:00'),
(713,	3,	'user-activities',	'/api/admin/user-activity-log',	'{ \"GET\":true }',	'{}',	'{}',	'0000-00-00 00:00:00',	'0000-00-00 00:00:00'),
(714,	3,	'roles',	'/api/admin/role',	'{ \"GET\":false, \"POST\": false, \"PUT\": false, \"DELETE\": false }',	'{}',	'{}',	'0000-00-00 00:00:00',	'0000-00-00 00:00:00'),
(715,	3,	'admin-user-access',	'/api/admin/admin-user-access',	'{\"GET\":true,\"PUT\":true,\"POST\":true}',	'{}',	'{}',	'0000-00-00 00:00:00',	'2018-02-19 14:20:11'),
(716,	3,	'admin-collect-distribute',	'/api/admin/admin-collect-distribute',	'{ \"GET\":true, \"POST\": true }',	'{}',	'{}',	'0000-00-00 00:00:00',	'0000-00-00 00:00:00'),
(717,	3,	'issue-collect-money',	NULL,	'{ \"GET\":false, \"POST\": false }',	'{}',	'{}',	'0000-00-00 00:00:00',	'0000-00-00 00:00:00'),
(718,	3,	'feature-acl',	'/api/admin/feature-acl',	'{\"GET\": true, \"PUT\": true }',	'{}',	'{}',	'0000-00-00 00:00:00',	'0000-00-00 00:00:00'),
(719,	4,	'users',	'/api/admin/user',	'{\"GET\":false,\"PUT\":false}',	'{\"ALL\":false,\"updateStatusOfUser\":false,\"updateStatusOfDocument\":false,\"updateStatsOfPhone\":false,\"updateStatsOfFacebook\":false,\"updateStatsOfID\":false,\"updateStatsOfAddress\":false,\"LOAN\":false}',	'{\"viewWithoutOTP\":false,\"viewWithOTP\":true,\"triggerCreditStore\":false}',	'0000-00-00 00:00:00',	'2018-02-19 15:52:07'),
(720,	4,	'loans',	'/api/admin/loan',	'{\"GET\": true, \"PUT\": true }',	'{\"ALL\": true, \"status\": true}',	'{ \"cancelLoanBasedOnStatus\": false, \"cancelLoanBasedOnStatusNotGiven\": false, \"closeLoan\": false, \"issueMoney\": true}',	'0000-00-00 00:00:00',	'0000-00-00 00:00:00'),
(721,	4,	'collections',	'/api/admin/collection',	'{\"GET\":true,\"PUT\":true}',	'{\"ALL\":true}',	'{\"collectMoney\":true}',	'0000-00-00 00:00:00',	'2018-02-19 14:21:06'),
(723,	4,	'countries',	'/api/admin/country',	'{ \"GET\":false, \"POST\": false, \"PUT\": false, \"DELETE\": false }',	'{}',	'{}',	'0000-00-00 00:00:00',	'0000-00-00 00:00:00'),
(724,	4,	'country-settings',	'/api/admin/country-setting',	'{ \"GET\":false, \"POST\": false, \"PUT\": false, \"DELETE\": false }',	'{}',	'{}',	'0000-00-00 00:00:00',	'0000-00-00 00:00:00'),
(725,	4,	'country-investments',	'/api/admin/country-investment',	'{ \"GET\":false, \"POST\": false, \"PUT\": false, \"DELETE\": false }',	'{}',	'{}',	'0000-00-00 00:00:00',	'0000-00-00 00:00:00'),
(726,	4,	'non-supported-country-leads',	'/api/admin/non-supported-country-lead',	'{ \"GET\":false }',	'{}',	'{}',	'0000-00-00 00:00:00',	'0000-00-00 00:00:00'),
(727,	4,	'companies',	'/api/admin/company',	'{ \"GET\":false, \"POST\": false, \"PUT\": false, \"DELETE\": false }',	'{}',	'{}',	'0000-00-00 00:00:00',	'0000-00-00 00:00:00'),
(728,	4,	'distribution-centers',	'/api/admin/distribution-center',	'{ \"GET\":false, \"POST\": false, \"PUT\": false, \"DELETE\": false }',	'{}',	'{}',	'0000-00-00 00:00:00',	'0000-00-00 00:00:00'),
(729,	4,	'admin-users',	'/api/admin/admin-user',	'{ \"GET\":false, \"POST\": false, \"PUT\": false, \"DELETE\": false }',	'{}',	'{ \"createSuperAdminUser\": false, \"2FA\": true }',	'0000-00-00 00:00:00',	'0000-00-00 00:00:00'),
(731,	4,	'user-activities',	'/api/admin/user-activity-log',	'{ \"GET\":true }',	'{}',	'{}',	'0000-00-00 00:00:00',	'0000-00-00 00:00:00'),
(732,	4,	'roles',	'/api/admin/role',	'{ \"GET\":false, \"POST\": false, \"PUT\": false, \"DELETE\": false }',	'{}',	'{}',	'0000-00-00 00:00:00',	'0000-00-00 00:00:00'),
(733,	4,	'admin-user-access',	'/api/admin/admin-user-access',	'{\"GET\":true,\"PUT\":true,\"POST\":true}',	'{}',	'{}',	'0000-00-00 00:00:00',	'2018-02-19 14:22:43'),
(734,	4,	'admin-collect-distribute',	'/api/admin/admin-collect-distribute',	'{ \"GET\":true, \"POST\": true }',	'{}',	'{}',	'0000-00-00 00:00:00',	'0000-00-00 00:00:00'),
(735,	4,	'issue-collect-money',	NULL,	'{ \"GET\":true, \"POST\": true }',	'{}',	'{ \"viewWithoutOTP\": false, \"viewWithOTP\": true}',	'0000-00-00 00:00:00',	'0000-00-00 00:00:00'),
(736,	4,	'feature-acl',	'/api/admin/feature-acl',	'{\"GET\": true, \"PUT\": true }',	'{}',	'{}',	'0000-00-00 00:00:00',	'0000-00-00 00:00:00'),
(737,	5,	'users',	'/api/admin/user',	'{\"GET\":false,\"PUT\":false}',	'{\"ALL\":false,\"updateStatusOfUser\":false,\"updateStatusOfDocument\":false,\"updateStatsOfPhone\":false,\"updateStatsOfFacebook\":false,\"updateStatsOfID\":false,\"updateStatsOfAddress\":false,\"LOAN\":false}',	'{\"viewWithoutOTP\":false,\"viewWithOTP\":true,\"triggerCreditStore\":false}',	'0000-00-00 00:00:00',	'2018-02-19 15:59:03'),
(738,	5,	'loans',	'/api/admin/loan',	'{\"GET\": true, \"PUT\": true }',	'{\"ALL\": true, \"status\": true}',	'{ \"cancelLoanBasedOnStatus\": false, \"cancelLoanBasedOnStatusNotGiven\": false, \"closeLoan\": false, \"issueMoney\": true}',	'0000-00-00 00:00:00',	'0000-00-00 00:00:00'),
(739,	5,	'collections',	'/api/admin/collection',	'{\"GET\":true,\"PUT\":true}',	'{\"ALL\":true}',	'{\"collectMoney\":true}',	'0000-00-00 00:00:00',	'2018-02-19 16:05:33'),
(741,	5,	'countries',	'/api/admin/country',	'{ \"GET\":false, \"POST\": false, \"PUT\": false, \"DELETE\": false }',	'{}',	'{}',	'0000-00-00 00:00:00',	'0000-00-00 00:00:00'),
(742,	5,	'country-settings',	'/api/admin/country-setting',	'{ \"GET\":false, \"POST\": false, \"PUT\": false, \"DELETE\": false }',	'{}',	'{}',	'0000-00-00 00:00:00',	'0000-00-00 00:00:00'),
(743,	5,	'country-investments',	'/api/admin/country-investment',	'{ \"GET\":false, \"POST\": false, \"PUT\": false, \"DELETE\": false }',	'{}',	'{}',	'0000-00-00 00:00:00',	'0000-00-00 00:00:00'),
(744,	5,	'non-supported-country-leads',	'/api/admin/non-supported-country-lead',	'{ \"GET\":false }',	'{}',	'{}',	'0000-00-00 00:00:00',	'0000-00-00 00:00:00'),
(745,	5,	'companies',	'/api/admin/company',	'{ \"GET\":false, \"POST\": false, \"PUT\": false, \"DELETE\": false }',	'{}',	'{}',	'0000-00-00 00:00:00',	'0000-00-00 00:00:00'),
(746,	5,	'distribution-centers',	'/api/admin/distribution-center',	'{ \"GET\":false, \"POST\": false, \"PUT\": false, \"DELETE\": false }',	'{}',	'{}',	'0000-00-00 00:00:00',	'0000-00-00 00:00:00'),
(747,	5,	'admin-users',	'/api/admin/admin-user',	'{\"GET\":false,\"POST\":false,\"PUT\":false,\"DELETE\":false}',	'{}',	'{\"createSuperAdminUser\":false,\"2FA\":true}',	'0000-00-00 00:00:00',	'2018-02-19 14:21:52'),
(749,	5,	'user-activities',	'/api/admin/user-activity-log',	'{ \"GET\":true }',	'{}',	'{}',	'0000-00-00 00:00:00',	'0000-00-00 00:00:00'),
(750,	5,	'roles',	'/api/admin/role',	'{ \"GET\":false, \"POST\": false, \"PUT\": false, \"DELETE\": false }',	'{}',	'{}',	'0000-00-00 00:00:00',	'0000-00-00 00:00:00'),
(751,	5,	'admin-user-access',	'/api/admin/admin-user-access',	'{\"GET\":true,\"PUT\":true,\"POST\":true}',	'{}',	'{}',	'0000-00-00 00:00:00',	'2018-02-19 14:21:58'),
(752,	5,	'admin-collect-distribute',	'/api/admin/admin-collect-distribute',	'{ \"GET\":true, \"POST\": true }',	'{}',	'{}',	'0000-00-00 00:00:00',	'0000-00-00 00:00:00'),
(753,	5,	'issue-collect-money',	NULL,	'{ \"GET\":true, \"POST\": true }',	'{}',	'{\"viewWithoutOTP\":false,\"viewWithOTP\":true}',	'0000-00-00 00:00:00',	'0000-00-00 00:00:00'),
(754,	5,	'feature-acl',	'/api/admin/feature-acl',	'{\"GET\": true, \"PUT\": true }',	'{}',	'{}',	'0000-00-00 00:00:00',	'0000-00-00 00:00:00');

DROP TABLE IF EXISTS `Loans`;
CREATE TABLE `Loans` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date_taken` datetime DEFAULT NULL,
  `ammount_taken` double DEFAULT NULL,
  `service_fee` varchar(255) DEFAULT NULL,
  `interest_rate` varchar(255) DEFAULT NULL,
  `duration_of_loan` int(11) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `amount_pending` double DEFAULT NULL,
  `bank_credit_transaction` varchar(255) DEFAULT NULL,
  `bank_credit_status` tinyint(1) DEFAULT NULL,
  `currency` varchar(255) DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `user_payment_method_id` int(11) DEFAULT NULL,
  `admin_user_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `user_payment_method_id` (`user_payment_method_id`),
  KEY `admin_user_id` (`admin_user_id`),
  CONSTRAINT `Loans_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `Users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `Loans_ibfk_2` FOREIGN KEY (`user_payment_method_id`) REFERENCES `UserPaymentMethods` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `Loans_ibfk_4` FOREIGN KEY (`admin_user_id`) REFERENCES `AdminUsers` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


DROP TABLE IF EXISTS `LoansHistories`;
CREATE TABLE `LoansHistories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `bank_id` varchar(255) DEFAULT NULL,
  `date_taken` datetime DEFAULT NULL,
  `ammount_taken` double DEFAULT NULL,
  `service_fee` varchar(255) DEFAULT NULL,
  `interest_rate` varchar(255) DEFAULT NULL,
  `duration_of_loan` int(11) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `date` datetime DEFAULT NULL,
  `amount_pending` double DEFAULT NULL,
  `bank_credit_transaction` varchar(255) DEFAULT NULL,
  `bank_credit_status` tinyint(1) DEFAULT NULL,
  `currency` varchar(255) DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `loan_id` int(11) DEFAULT NULL,
  `admin_user_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `loan_id` (`loan_id`),
  KEY `admin_user_id` (`admin_user_id`),
  CONSTRAINT `LoansHistories_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `Users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `LoansHistories_ibfk_3` FOREIGN KEY (`loan_id`) REFERENCES `Loans` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `LoansHistories_ibfk_4` FOREIGN KEY (`admin_user_id`) REFERENCES `AdminUsers` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


DROP TABLE IF EXISTS `NonSupportedCountryLeads`;
CREATE TABLE `NonSupportedCountryLeads` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `country` varchar(255) DEFAULT NULL,
  `ip_address` varchar(255) DEFAULT NULL,
  `gps_location` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


DROP TABLE IF EXISTS `PaymentMethods`;
CREATE TABLE `PaymentMethods` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `settings` varchar(255) DEFAULT NULL,
  `type` enum('bank','wallet') DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `logo` varchar(255) DEFAULT NULL,
  `bank_code` varchar(255) DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  `country_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `country_id` (`country_id`),
  CONSTRAINT `PaymentMethods_ibfk_1` FOREIGN KEY (`country_id`) REFERENCES `Countries` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


DROP TABLE IF EXISTS `Roles`;
CREATE TABLE `Roles` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `role_id` varchar(255) DEFAULT NULL,
  `role_name` varchar(255) DEFAULT NULL,
  `max_session_time` varchar(255) DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


DROP TABLE IF EXISTS `SequelizeMeta`;
CREATE TABLE `SequelizeMeta` (
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`name`),
  UNIQUE KEY `name` (`name`),
  UNIQUE KEY `SequelizeMeta_name_unique` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


DROP TABLE IF EXISTS `SimBankAccounts`;
CREATE TABLE `SimBankAccounts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` enum('credit','debit') DEFAULT NULL,
  `amount` varchar(255) DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  `user_payment_method_id` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `user_payment_method_id` (`user_payment_method_id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `SimBankAccounts_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `Users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


DROP TABLE IF EXISTS `UserActivityLogs`;
CREATE TABLE `UserActivityLogs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `admin_user_id` int(11) DEFAULT NULL,
  `action` text,
  `payload` text,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  `user_email` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `admin_user_id` (`admin_user_id`),
  CONSTRAINT `UserActivityLogs_ibfk_1` FOREIGN KEY (`admin_user_id`) REFERENCES `AdminUsers` (`id`) ON DELETE NO ACTION ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


DROP TABLE IF EXISTS `UserPaymentMethods`;
CREATE TABLE `UserPaymentMethods` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `account` varchar(255) DEFAULT NULL,
  `sim_id` int(11) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `bank_name` varchar(255) DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `payment_method_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `payment_method_id` (`payment_method_id`),
  CONSTRAINT `UserPaymentMethods_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `Users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `UserPaymentMethods_ibfk_2` FOREIGN KEY (`payment_method_id`) REFERENCES `PaymentMethods` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


DROP TABLE IF EXISTS `Users`;
CREATE TABLE `Users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fname` varchar(255) DEFAULT NULL,
  `mname` varchar(255) DEFAULT NULL,
  `lname` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `dob` datetime DEFAULT NULL,
  `user_location` varchar(255) DEFAULT NULL,
  `access_token` varchar(255) DEFAULT NULL,
  `phone_number` varchar(255) DEFAULT NULL,
  `verified` tinyint(1) DEFAULT '0',
  `accept` int(11) DEFAULT NULL,
  `no_of_active_loans` double DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `sex` varchar(255) DEFAULT NULL,
  `profilepic` varchar(255) DEFAULT NULL,
  `relationship` varchar(255) DEFAULT NULL,
  `available_amount` double DEFAULT NULL,
  `min_availalble_amount` double DEFAULT '0',
  `number_of_attempts` int(1) DEFAULT '0',
  `last_attempts_time` datetime DEFAULT '2017-12-22 06:16:37',
  `created_at` datetime DEFAULT '2017-12-22 06:16:37',
  `umbrella_score` double DEFAULT '0',
  `fbId` varchar(255) DEFAULT NULL,
  `smscode` varchar(255) DEFAULT NULL,
  `uScore_status` varchar(255) DEFAULT NULL,
  `id_proof_file` varchar(255) DEFAULT NULL,
  `selfie_proof_file` varchar(255) DEFAULT NULL,
  `address_proof_file` varchar(255) DEFAULT NULL,
  `selfie_proof_video` varchar(255) NOT NULL,
  `id_verification_status` varchar(255) DEFAULT NULL,
  `address_verification_status` varchar(255) DEFAULT NULL,
  `updated_at` datetime NOT NULL,
  `country_id` int(11) DEFAULT NULL,
  `fcm_token` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `country_id` (`country_id`),
  CONSTRAINT `Users_ibfk_1` FOREIGN KEY (`country_id`) REFERENCES `Countries` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


-- 2018-02-22 17:04:28
